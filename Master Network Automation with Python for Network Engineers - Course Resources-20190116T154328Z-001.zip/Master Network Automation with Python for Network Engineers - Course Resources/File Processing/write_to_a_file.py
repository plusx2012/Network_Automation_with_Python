with open('a.txt', 'a') as f: #file was opened in append mode (add the the end)
    f.write('\n some text')     #write a string at the end of the file

