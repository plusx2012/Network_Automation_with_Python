**Master Network Automation with Python for Network Engineers  (95% off, only $9.99)**
https://www.udemy.com/master-python-network-automation-for-network-engineers/?couponCode=BOOSTYOURSKILLS